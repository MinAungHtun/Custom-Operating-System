
#ifndef __COMMON__VECTOR_H
    #define __COMMON__VECTOR_H

    #include <common/types.h>

    namespace MYYOS
    {
        namespace common
        {



            template<class T> class VectorIterationHandler
            {
                public:
                    VectorIterationHandler();
                    ~VectorIterationHandler();
                    virtual void OnRead(T);
                    virtual void OnEndOfStream();
            };




            template<class T> class Vector
            {
                protected:
                    T elements[100];    // fake - currently max 100 elements - but the interface should be used already
                    uint32_t Size;
                    uint32_t MaxSize;
                public:
                    typedef T* iterator;

                    Vector();
                    Vector(int size, T element);
                    ~Vector();

                    T& operator[](int index);
                    uint32_t size();
                    iterator begin();
                    iterator end();
                    iterator find(T element);
                    bool empty();

                    iterator push_back(T element);
                    void pop_back();
                    iterator push_front(T element);
                    void pop_front();
                    void erase(T element);
                    void erase(iterator position);
                    void clear();

                    void Iterate(VectorIterationHandler<T>* handler);
                    void Iterate(void callback(T&));
            };



        }
    }

    #include "../../src/common/vector_templates.cpp"

#endif