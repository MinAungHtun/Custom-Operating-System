
#include<applications/application.h>

namespace MYYOS
{
    namespace applications
    {
        
        Application::Application()
         :  GraphicalObject()
        {

        }

        Application::~Application()
        {
        }

    }
}

